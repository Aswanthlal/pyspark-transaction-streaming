# Databricks notebook source
# MAGIC %run /Users/aswanthlal11@gmail.com/transaction_detection_project/config/config
# MAGIC %run /Users/aswanthlal11@gmail.com/transaction_detection_project/utils/spark_io
# MAGIC %run /Users/aswanthlal11@gmail.com/transaction_detection_project/utils/postgres_utils


# COMMAND ----------

# MAGIC %run /Users/aswanthlal11@gmail.com/transaction_detection_project/config/config
# MAGIC %run /Users/aswanthlal11@gmail.com/transaction_detection_project/utils/spark_io

from pyspark.sql import SparkSession
from pyspark.sql.functions import monotonically_increasing_id
from datetime import datetime
import uuid

# Initialize Spark
spark = SparkSession.builder.appName("ChunkWriter").getOrCreate()

# Read real data
df = spark.read.csv("dbfs:/tmp/transactions/transactions.csv", header=True, inferSchema=True)

# Use the loaded variable from config
df = df.withColumn("row_id", monotonically_increasing_id())
total_rows = df.count()
num_chunks = (total_rows + chunk_size - 1) // chunk_size  # <-- chunk_size from config notebook

for i in range(num_chunks):
    chunk_df = df.filter((df.row_id >= i * chunk_size) & (df.row_id < (i + 1) * chunk_size)).drop("row_id")
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    filename = f"chunk_{timestamp}_{uuid.uuid4().hex[:6]}"
    path = f"s3a://{bucket}/stream_chunks/{filename}"  # <-- bucket from config
    write_chunk_to_s3(chunk_df, path)  # <-- from spark_io notebook

print(f"Wrote {num_chunks} chunks to S3.")
