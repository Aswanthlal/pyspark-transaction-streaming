# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql import DataFrame
from pyspark.sql.window import Window

def detect_patid1(df_txn: DataFrame, df_importance: DataFrame) -> DataFrame:
    df_joined = df_txn.alias("tx").join(
        df_importance.alias("imp"),
        (F.col("tx.customer") == F.col("imp.customer")) &
        (F.col("tx.merchant") == F.col("imp.merchant")),
        how="inner"
    )

    merchant_txn_counts = df_txn.groupBy("merchant").count().withColumnRenamed("count", "total_txns")
    eligible_merchants = merchant_txn_counts.filter(F.col("total_txns") > 50000)

    df_joined = df_joined.join(
        eligible_merchants.alias("em"),
        F.col("tx.merchant") == F.col("em.merchant"),
        how="inner"
    )

    agg_df = df_joined.groupBy(
        F.col("tx.customer").alias("customer"),
        F.col("tx.merchant").alias("merchant")
    ).agg(
        F.count("*").alias("txn_count"),
        F.avg(F.col("imp.Weight")).alias("avg_weight")
    )

    window_spec = Window.partitionBy("merchant").orderBy(F.col("txn_count").desc())
    window_spec_weight = Window.partitionBy("merchant").orderBy(F.col("avg_weight").asc())

    ranked_df = agg_df.withColumn("txn_rank", F.percent_rank().over(window_spec)) \
                      .withColumn("weight_rank", F.percent_rank().over(window_spec_weight))

    patid1 = ranked_df.filter(
        (F.col("txn_rank") <= 0.01) & (F.col("weight_rank") <= 0.01)
    ).withColumn("patternId", F.lit("PatId1")) \
     .withColumn("actionType", F.lit("UPGRADE"))

    return patid1

def detect_patid2(df_txn: DataFrame) -> DataFrame:
    agg_df = df_txn.groupBy("customer", "merchant").agg(
        F.count("*").alias("txn_count"),
        F.avg("amount").alias("avg_amount")
    )

    patid2 = agg_df.filter(
        (F.col("txn_count") >= 80) & (F.col("avg_amount") < 23)
    ).withColumn("patternId", F.lit("PatId2")) \
     .withColumn("actionType", F.lit("CHILD"))

    return patid2

def detect_patid3(df_txn: DataFrame) -> DataFrame:
    df_gender_base = df_txn.select("merchant", "customer", "gender").dropDuplicates()

    gender_counts = df_gender_base.groupBy("merchant", "gender").agg(
        F.countDistinct("customer").alias("cust_count")
    ).groupBy("merchant").pivot("gender", ["F", "M"]).sum("cust_count").na.fill(0)

    patid3 = gender_counts.filter(
        (F.col("F") > 100) & (F.col("F") < F.col("M"))
    ).withColumn("patternId", F.lit("PatId3")) \
     .withColumn("actionType", F.lit("DEI-NEEDED")) \
     .withColumn("customerName", F.lit("")) \
     .withColumn("merchantId", F.col("merchant"))

    return patid3
