# Databricks notebook source
from pyspark.sql import DataFrame
from datetime import datetime
from pytz import timezone

def harmonize_columns(df: DataFrame, target_cols: list) -> DataFrame:
    for col in target_cols:
        if col not in df.columns:
            df = df.withColumn(col, F.lit(""))
    return df.select(target_cols)

def write_batches_to_s3(df: DataFrame, bucket: str, chunk_name: str):
    rows = df.collect()
    ist_time = datetime.now(timezone("Asia/Kolkata")).strftime("%Y-%m-%d %H:%M:%S")

    for i in range(0, len(rows), 50):
        batch = rows[i:i+50]
        if not batch:
            continue

        batch_df = spark.createDataFrame(batch, df.schema) \
            .withColumn("YStartTime", F.lit(ist_time)) \
            .withColumn("detectionTime", F.current_timestamp()) \
            .withColumn("detectionTime", F.date_format(
                F.from_utc_timestamp("detectionTime", "Asia/Kolkata"), "yyyy-MM-dd HH:mm:ss")) \
            .withColumn("customerName", F.coalesce(F.col("customer"), F.lit(""))) \
            .withColumn("merchantId", F.coalesce(F.col("merchant"), F.lit(""))) \
            .select("YStartTime", "detectionTime", "patternId", "actionType", "customerName", "merchantId")

        output_path = f"s3a://{bucket}/pattern_detections/pattern_output_{chunk_name}_batch_{i//50 + 1}.csv"
        batch_df.coalesce(1).write.mode("overwrite").option("header", True).csv(output_path)
