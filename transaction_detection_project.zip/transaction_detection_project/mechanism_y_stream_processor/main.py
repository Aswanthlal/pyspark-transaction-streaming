# Databricks notebook source
# --- Imports ---
from config import *
from utils.postgres_utils import get_processed_chunks, log_processed_chunk
from mechanism_y_stream_processor.pattern_detection import detect_patid1, detect_patid2, detect_patid3
from mechanism_y_stream_processor.writers import harmonize_columns, write_batches_to_s3

from pyspark.sql.functions import lit
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType

# --- Schema ---
chunk_schema = StructType([
    StructField("step", IntegerType(), True),
    StructField("customer", StringType(), True),
    StructField("age", StringType(), True),
    StructField("gender", StringType(), True),
    StructField("zipcodeOri", StringType(), True),
    StructField("merchant", StringType(), True),
    StructField("zipMerchant", StringType(), True),
    StructField("category", StringType(), True),
    StructField("amount", DoubleType(), True),
    StructField("fraud", IntegerType(), True)
])

# --- Process Start ---
processed = get_processed_chunks(pg_conn_params)
files = [f.path for f in dbutils.fs.ls(s3_chunk_dir) if f.path.endswith(".csv/")]

df_importance = spark.read.csv("dbfs:/tmp/transactions/CustomerImportance.csv", header=True, inferSchema=True)
df_importance = df_importance.withColumnRenamed("Source", "customer") \
                             .withColumnRenamed("Target", "merchant") \
                             .withColumnRenamed("typeTrans", "category")

for file_path in files:
    chunk_name = file_path.rstrip("/").split("/")[-1]
    if chunk_name in processed:
        print(f"Already processed: {chunk_name}")
        continue

    print(f"Processing: {chunk_name}")
    df_chunk = spark.read.schema(chunk_schema).option("header", True).csv(file_path)
    df_chunk = df_chunk.withColumn("chunk_name", lit(chunk_name))

    # Run pattern detection
    patid1_df = detect_patid1(df_chunk, df_importance)
    patid2_df = detect_patid2(df_chunk)
    patid3_df = detect_patid3(df_chunk)

    # Harmonize
    all_cols = [
        "customer", "merchant", "txn_count", "avg_weight", "txn_rank", "weight_rank",
        "patternId", "actionType", "avg_amount", "F", "M", "customerName", "merchantId"
    ]
    patid1_df = harmonize_columns(patid1_df, all_cols)
    patid2_df = harmonize_columns(patid2_df, all_cols)
    patid3_df = harmonize_columns(patid3_df, all_cols)

    final_df = patid1_df.unionByName(patid2_df).unionByName(patid3_df)

    # Write batches to S3
    write_batches_to_s3(final_df, bucket_name, chunk_name)

    # Mark processed
    log_processed_chunk(pg_conn_params, chunk_name)

    print(f"✅ Finished: {chunk_name}")
