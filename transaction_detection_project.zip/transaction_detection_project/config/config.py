# Databricks notebook source
# --- S3 Configuration ---
bucket_name = "bucket-aswanthlal-20250609123312"
chunk_dir = "dbfs:/stream_chunks"

s3_output_dir = f"s3a://{bucket_name}/pattern_detections"

access_key = "AKIAU76LUFEGVNYPMUVE"
secret_key = "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"
region = "ap-south-1"

# Setup for Spark to access S3
spark._jsc.hadoopConfiguration().set("fs.s3a.access.key", access_key)
spark._jsc.hadoopConfiguration().set("fs.s3a.secret.key", secret_key)
spark._jsc.hadoopConfiguration().set("fs.s3a.endpoint", f"s3.{region}.amazonaws.com")

# --- PostgreSQL Configuration ---
jdbc_url = "jdbc:postgresql://txndb.cvskc4cqgii5.ap-south-1.rds.amazonaws.com:5432/postgres"
jdbc_props = {
    "user": "txn_postgres",
    "password": "rootroot",
    "driver": "org.postgresql.Driver"
}
pg_conn_params = {
    "host": "txndb.cvskc4cqgii5.ap-south-1.rds.amazonaws.com",
    "port": 5432,
    "dbname": "postgres",
    "user": "txn_postgres",
    "password": "rootroot"
}

# Other
chunk_size = 10000
processed_table = "processed_chunks"
pattern_output_table = "detected_patterns"
print("✅ Config loaded")
# config/config (Notebook)

chunk_size = 10000
jdbc_url =jdbc_url
print("✅ Config loaded!")

