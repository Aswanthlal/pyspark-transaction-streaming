# Databricks notebook source
# Databricks notebook: download_data
# Downloads dataset from Google Drive using gdown and saves it to DBFS

%pip install gdown
import gdown

# Set Google Drive folder URL and target path
url = "https://drive.google.com/drive/folders/1qryhdlgNsmecWRy2haI8S3uC63wKk5X-"
output_path = "/dbfs/tmp/transactions"

# Download data
gdown.download_folder(url=url, output=output_path, quiet=False, use_cookies=False)

# Move CSVs to DBFS for Spark access
dbutils.fs.mv("file:/dbfs/tmp/transactions/transactions.csv", "dbfs:/tmp/transactions/transactions.csv")
dbutils.fs.mv("file:/dbfs/tmp/transactions/CustomerImportance.csv", "dbfs:/tmp/transactions/CustomerImportance.csv")


# COMMAND ----------

