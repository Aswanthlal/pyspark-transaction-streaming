# Databricks notebook source
from datetime import datetime

def write_csv_to_s3(df, s3_path):
    df.coalesce(1).write.mode("overwrite").option("header", True).csv(s3_path)
    print(f"✅ Written to: {s3_path}")
