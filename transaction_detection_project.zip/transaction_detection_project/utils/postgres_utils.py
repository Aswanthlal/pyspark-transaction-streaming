# Databricks notebook source
import psycopg2

def get_processed_chunks(pg_conn_params):
    conn = psycopg2.connect(**pg_conn_params)
    cursor = conn.cursor()
    cursor.execute("CREATE TABLE IF NOT EXISTS processed_chunks (chunk_name TEXT PRIMARY KEY, processed_at TIMESTAMP DEFAULT now())")
    conn.commit()
    cursor.execute("SELECT chunk_name FROM processed_chunks")
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    return {row[0] for row in rows}

def log_processed_chunk(pg_conn_params, chunk_name):
    conn = psycopg2.connect(**pg_conn_params)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO processed_chunks (chunk_name) VALUES (%s) ON CONFLICT DO NOTHING", (chunk_name,))
    conn.commit()
    cursor.close()
    conn.close()
